#!/bin/bash

#Create an private key in console aws and add the name in the variable 'PRIVATE_KEY'.
PRIVATE_KEY="reinaldosouza"

printf "\nCreating stack CloudFormation VPC......\n"
aws cloudformation create-stack --stack-name devops-stack-vpc --template-body file://vpc.json
printf "\nLoading......\n"
sleep 90

VPC=$(aws cloudformation describe-stacks --stack-name devops-stack-vpc |egrep -i 'vpc-'|awk '{print $(NF)}'|sed 's/\"//g'|tail -1)
SUBNET=$(aws cloudformation describe-stacks --stack-name devops-stack-vpc |egrep -i 'subnet-'|awk '{print $(NF)}'|sed 's/\"//g'|tail -1)
SECURITYGROUP=$(aws cloudformation describe-stacks --stack-name devops-stack-vpc |egrep -i 'sg-'|awk '{print $(NF)}'|sed 's/\"//g'|tail -1)
printf "\nCreated VPC $VPC, SUBNET $SUBNET and SECURITYGROUP $SECURITYGROUP......\n"

printf "\nChanging file EC2 CloudFormation......\n"
cp template-ec2.json ec2.json
sed -i "s/privatekey/${PRIVATE_KEY}/g" ec2.json
sed -i "s/subnet/${SUBNET}/g" ec2.json
sed -i "s/securitygroup/${SECURITYGROUP}/g" ec2.json

printf "\nCreating stack CloudFormation EC2......\n"
aws cloudformation create-stack --stack-name devops-stack-ec2 --template-body file://ec2.json

printf "\nLoading......\n"
sleep 60
aws cloudformation describe-stacks --stack-name devops-stack-ec2 |egrep 'InstanceId|PublicIP' -A1|grep -vi description|awk '{print $(NF)}'
