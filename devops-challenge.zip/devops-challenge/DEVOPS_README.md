
# Devops-Reinaldo-Pinto
Infraestrutura: Cloud Formation AWS - Docker

####**Teste1**
Execute os passos a seguir de  preferencia na região da us-east (Virginia), pois os testes foram executados tambem nessa região.
Primeiro criei uma Private Key (chave privada) na console da AWS, altere a variavel no arquivo script.sh.
Configure uma access key e secret key do seu usuario da aws na sua maquina.
De as permissoes necessárias para o script:
```
chmod a+x script.sh
```
Execute o mesmo para criar a infraestrtura na aws:
```
./script.sh
```
Após execute o curl usando o IP publico atribuido a ec2.
```
curl -H "Authorization: Token 10bdfabd54f47a3f4e6b6b9e3f0061b3"  http://<ip>/
```

Token default: 10bdfabd54f47a3f4e6b6b9e3f0061b3

Para alterar o token, acesse a ec2 e siga os passos abaixo.

Remover containers docker:
```
sudo docker rm -f $(sudo docker ps -qa)
```
Criar um novo container com o novo token:
```
docker run -d --rm -e GERU_PASS=<novo_token> -p 80:80 reinaldopinto/devops-challenge
```

####**Teste2**

- Essa arquitetura, utiza o cloudfront como endpoint principal, para  o uso de cache e mapeamento do s3 e apigateway.
- S3, teoricamente para seus arquivos estaticos, frontend.
- Apigateway, para o mapeamento das chamadas das apis, abstraindo essa tratativa da aplicação, o mesmo esta usando o recurso lambda, mas poderia utilizar outro por exemplo beanstalk.
- Lambda, arquitetura serverless que teoricamente faz o papel de backend (consultando o banco de dados dynamodb), o mesmo é executado a base de algum evento.
- Dynamodb, banco de dados nosql, usado para armazenar seus dados, que possui um desempenho muito relevante.
